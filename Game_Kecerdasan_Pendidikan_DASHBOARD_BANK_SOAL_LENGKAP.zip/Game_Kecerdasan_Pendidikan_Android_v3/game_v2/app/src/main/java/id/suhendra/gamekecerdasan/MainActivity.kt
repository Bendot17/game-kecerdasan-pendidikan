package id.suhendra.gamekecerdasan

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Button
import android.widget.TextView
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.PreloadConfiguration
import com.google.android.libraries.ads.mobile.sdk.rewarded.RewardedAdPreloader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var root: LinearLayout
    private lateinit var assetLoader: WebViewAssetLoader
    private var bannerView: AdView? = null
    private var adsEnabled = false
    private var sdkReady = false
    private val rewardedUnitId = "ca-app-pub-3940256099942544/5224354917" // TEST ADS
    private val productionRewardedUnitId = "ca-app-pub-8704022903417472/4108143571"
    private val bannerUnitId = "ca-app-pub-3940256099942544/9214589741" // TEST ADS
    private val productionBannerUnitId = "ca-app-pub-8704022903417472/8260634866"
    private val sampleAppId = "ca-app-pub-8704022903417472~2224216264" // AdMob App ID akun pribadi

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("gkp_privacy", MODE_PRIVATE)
        val savedAge = prefs.getString("age_group_17plus", null)
        if (savedAge == null) {
            showAgeChoice { choice ->
                prefs.edit().putString("age_group_17plus", choice).apply()
                startGame(choice == "adult", savedInstanceState)
            }
        } else {
            startGame(savedAge == "adult", savedInstanceState)
        }
    }

    private fun showAgeChoice(onChoice: (String) -> Unit) {
        // Pilihan usia wajib dipilih saat pertama kali aplikasi dibuka.
        // Iklan diaktifkan untuk kelompok usia 17 tahun ke atas.
        val labels = arrayOf(
            "Di bawah 13 tahun",
            "13–16 tahun",
            "17 tahun ke atas"
        )
        val values = arrayOf("child", "teen", "adult")

        val dialog = AlertDialog.Builder(this)
            .setTitle("Pilih kelompok usia")
            .setItems(labels) { d, which ->
                d.dismiss()
                onChoice(values[which])
            }
            .setCancelable(false)
            .create()

        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    private fun startGame(allowAds: Boolean, savedInstanceState: Bundle?) {
        adsEnabled = allowAds
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -1)
        }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.addJavascriptInterface(GameBridge(), "AndroidAds")
        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (!adsEnabled) {
                    view.evaluateJavascript("document.getElementById('rewardAdPanel')?.classList.add('hidden')", null)
                }
            }
        }
        webView.webChromeClient = WebChromeClient()
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))

        if (allowAds) {
            val bannerContainer = FrameLayout(this)
            root.addView(bannerContainer, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER })
            setContentView(root)
            initializeAds(bannerContainer)
        } else {
            setContentView(root)
        }

        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun initializeAds(bannerContainer: FrameLayout) {
        // Only users who selected 17+ reach this point. Ad handling must follow applicable age and ads policies.
        Executors.newSingleThreadExecutor().execute {
            try {
                MobileAds.initialize(this, InitializationConfig.Builder(sampleAppId).build()) {
                    runOnUiThread {
                        sdkReady = true
                        loadBanner(bannerContainer)
                        preloadRewarded()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this, "AdMob belum dapat diinisialisasi", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun loadBanner(container: FrameLayout) {
        val adView = AdView(this)
        bannerView = adView
        container.addView(adView)
        val widthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val size = AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, widthDp)
        val request = BannerAdRequest.Builder(bannerUnitId, size).build()
        adView.loadAd(request, object : AdLoadCallback<BannerAd> {
            override fun onAdLoaded(ad: BannerAd) { }
            override fun onAdFailedToLoad(adError: LoadAdError) { }
        })
    }

    private fun preloadRewarded() {
        if (!sdkReady) return
        try {
            val request = AdRequest.Builder(rewardedUnitId).build()
            RewardedAdPreloader.start(rewardedUnitId, PreloadConfiguration(request))
        } catch (_: Exception) { }
    }

    private inner class GameBridge {
        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                if (!adsEnabled || !sdkReady) {
                    Toast.makeText(this@MainActivity, "Iklan belum siap. Coba beberapa saat lagi.", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val ad = RewardedAdPreloader.pollAd(rewardedUnitId)
                if (ad == null) {
                    Toast.makeText(this@MainActivity, "Video berhadiah belum tersedia. Coba lagi nanti.", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                ad.show(this@MainActivity) {
                    runOnUiThread {
                        webView.evaluateJavascript("window.onNativeRewardedAdEarned && window.onNativeRewardedAdEarned(20)", null)
                        Toast.makeText(this@MainActivity, "Bonus 20 koin berhasil ditambahkan!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        bannerView?.destroy()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
