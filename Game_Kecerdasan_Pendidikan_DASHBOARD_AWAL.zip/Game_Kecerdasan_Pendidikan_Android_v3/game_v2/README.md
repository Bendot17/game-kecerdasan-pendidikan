# Game Kecerdasan Pendidikan
**Developed by SUHENDRA**

Game edukasi Android berbasis Kotlin + WebView. Permainan berjalan offline dengan HTML/CSS/JavaScript lokal.

## Fitur
- Kuis pilihan ganda dengan kategori: Kecerdasan & Logika, Komputer, Matematika, Pengetahuan Umum, Bahasa Indonesia, Bahasa Inggris, Seni & Kreativitas.
- Tingkat kesulitan: Mudah, Sedang, Sulit.
- Mode kuis dengan timer, skor, nyawa, progres, hasil, dan pembahasan.
- Mini tantangan: tebak pola angka dan benar/salah.
- Progres dan rekor tersimpan lokal pada perangkat menggunakan localStorage.
- Tampilan responsif untuk layar Android.
- Dapat dimainkan tanpa internet.

## Membuka dan membangun APK
1. Ekstrak ZIP.
2. Buka folder `Game_Kecerdasan_Pendidikan` melalui Android Studio (Open).
3. Tunggu Gradle sync. Proyek menggunakan Android Gradle Plugin 8.6.1 dan Gradle 8.7.
4. Pastikan Android SDK Platform 35 terpasang.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- `gradlew` tidak disertakan. Android Studio dapat menggunakan Gradle 8.7 yang diunduh/tersedia pada instalasi Anda.
- `minSdk 23`, `targetSdk 35`.
- Nama aplikasi: Game Kecerdasan Pendidikan.
- Developer credit: Developed by SUHENDRA.


## Fitur versi 3.0
- Profil pemain: nama dan jenjang (SD/MI, SMP/MTs, SMA/SMK/MA, mahasiswa, atau umum).
- Tingkat kesulitan Mudah, Sedang, dan Sulit yang mengatur waktu menjawab serta jumlah nyawa.
- Hasil permainan menampilkan nama, jenjang, tingkat kesulitan, dan tombol cetak/simpan sertifikat melalui fitur cetak browser.
- Profil dan statistik disimpan lokal di perangkat melalui penyimpanan browser.


## Fitur versi 4.0
- Misi harian berisi lima soal campuran dan bonus 25 poin jika semua benar.
- Bantuan 50:50 sekali pakai dalam satu sesi kuis.
- Bonus kombo: tiga jawaban benar berturut-turut memberi tambahan 5 poin.
- Efek suara singkat yang dapat diaktifkan atau dimatikan.
- Papan peringkat lokal berisi lima skor terbaik pada perangkat.
- Pencapaian pemain berdasarkan jumlah permainan, rekor, dan total poin.
- Riwayat peringkat dan progres tersimpan lokal di browser/perangkat.


## Fitur versi 5.0
- Arena Duel dua pemain pada satu perangkat: 10 soal bergantian, skor terpisah, dan pengumuman pemenang/seri.
- Sistem XP dan koin: XP bertambah berdasarkan poin permainan dan koin diperoleh setiap 10 poin.
- XP dan koin disimpan bersama profil pemain secara lokal.

## Fitur versi 6.0 — Arena Duel Online dua HP
- Arena Duel online menggunakan Firebase Realtime Database.
- Pemain pertama membuat room dan membagikan kode 6 karakter.
- Pemain kedua bergabung dengan memasukkan kode room dari HP berbeda.
- Kedua pemain menjawab soal yang sama secara bersamaan dari perangkat masing-masing.
- Masing-masing pemain memiliki 2 nyawa; jawaban salah atau waktu habis mengurangi 1 nyawa.
- Skor, nyawa, jawaban per ronde, dan status pertandingan disinkronkan secara real-time.
- Login teknis menggunakan Firebase Anonymous Authentication; pemain tidak perlu membuat akun Google.

### Konfigurasi Firebase wajib sebelum Arena Online digunakan
1. Buat project di https://console.firebase.google.com/.
2. Tambahkan aplikasi Web pada Project settings > General > Your apps.
3. Aktifkan **Authentication > Sign-in method > Anonymous**.
4. Buat **Realtime Database** pada region Asia Southeast (Singapore) dan salin URL database.
5. Salin konfigurasi Web Firebase (apiKey, authDomain, databaseURL, projectId, appId).
6. Buka `app/src/main/assets/index.html`, cari `FIREBASE_CONFIG`, lalu ganti semua nilai `GANTI_...` dengan konfigurasi project Firebase milik Anda.
7. Pada Realtime Database > Rules, pasang aturan awal berikut untuk pengujian:

```json
{
  "rules": {
    "arenaRooms": {
      "$room": {
        ".read": "auth != null",
        ".write": "auth != null",
        ".validate": "newData.hasChildren(['status', 'hostUid', 'players'])"
      }
    }
  }
}
```

Aturan di atas adalah aturan awal untuk uji coba, bukan aturan produksi yang membatasi pemain hanya pada anggota room. Sebelum dipakai secara publik, aturan perlu diperketat agar hanya host dan guest room terkait yang dapat membaca/menulis room, serta validasi skor/nyawa dilakukan di backend tepercaya.
8. Buka proyek di Android Studio, lakukan Gradle Sync, lalu Build APK.

### Catatan teknis
- Koneksi internet diperlukan untuk memuat Firebase SDK dan bermain Arena Duel Online.
- Fitur kuis lain tetap dapat berjalan lokal/offline.
- Papan peringkat umum, akun permanen, toko koin/avatar online, dan verifikasi anti-cheat server belum diaktifkan pada versi ini. Koin dan statistik permainan lokal yang sudah ada tetap tersimpan di perangkat.
- APK belum dikompilasi di lingkungan ini; proyek Android Studio telah diperbarui dan perlu dibangun di Android Studio setelah konfigurasi Firebase diisi.


## Fitur versi 7.0 — Pengayaan soal, peringkat global, dan koin online
- Bank soal pengayaan berdasarkan jenjang SD/MI, SMP/MTs, SMA/SMK/MA, dan Mahasiswa.
- Mode Sulit menambahkan soal penalaran, matematika terapan, keamanan digital, algoritma, sains, dan analisis sesuai jenjang.
- Jenjang SMA/SMK/MA dan Mahasiswa otomatis mendapat soal pengayaan.
- Papan peringkat global menampilkan 10 skor terbaik berdasarkan bestScore.
- Dompet koin dan XP disimpan pada `playerProfiles/{uid}` di Firebase Realtime Database.
- Kredit koin dibuat per sesi permainan dengan penanda run unik agar satu sesi tidak dikreditkan dua kali oleh pemanggilan sinkronisasi yang sama.
- Profil global dan statistik skor diperbarui setelah sesi kuis selesai.

### Struktur Realtime Database tambahan
```json
{
  "rules": {
    "playerProfiles": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": "auth != null && auth.uid === $uid"
      }
    },
    "coinCredits": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": "auth != null && auth.uid === $uid"
      }
    },
    "globalLeaderboard": {
      ".read": "auth != null",
      "$uid": {
        ".write": "auth != null && auth.uid === $uid"
      }
    },
    "arenaRooms": {
      "$room": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
}
```
**Penting:** Rules di atas adalah aturan minimum untuk pengujian, bukan keamanan produksi. Karena aplikasi ini menggunakan Firebase Anonymous Authentication dan menulis skor/koin dari klien, pengguna teknis dapat memodifikasi data melalui perangkat atau REST API. Untuk peluncuran publik, pindahkan pemberian koin, validasi hasil, dan pembaruan leaderboard ke Cloud Functions/Cloud Run dengan App Check serta validasi server. Jangan gunakan Rules terbuka untuk `arenaRooms` di produksi; batasi akses hanya untuk anggota room.

### Catatan akun lintas perangkat
- Firebase Anonymous Authentication membuat identitas persisten pada instalasi/perangkat yang sama, tetapi identitas anonim tidak otomatis dapat dipulihkan di HP lain atau setelah data aplikasi dihapus.
- Jika koin dan profil harus ikut saat siswa berganti HP, tambahkan login akun permanen (email/password atau penyedia identitas) dan proses link/upgrade dari akun anonim. Fitur login permanen belum dikonfigurasi dalam paket ini.
- Firebase config tetap harus diisi di `FIREBASE_CONFIG`; aktifkan Anonymous Authentication dan buat Realtime Database. Aturan database harus diperbarui seperti di atas.
- APK belum dikompilasi dan belum diuji dengan Firebase project nyata.


## AdMob test integration
- Neutral age choice appears on first launch. Only the 18+ choice initializes Google Mobile Ads.
- Under 13, 13–17, and continue-without-ads choices do not initialize the ad SDK or request ads.
- Google test app ID, banner ID, and rewarded video ID are used. Replace them with your own AdMob IDs only after account/app setup and policy review.
- Minimum Android version is API 24 because GMA Next-Gen SDK requires it.


## Integrasi AdMob akun pribadi

App ID akun: `ca-app-pub-8704022903417472~2224216264`

Unit iklan produksi (disimpan sebagai konfigurasi, belum dipakai selama uji):
- Banner: `ca-app-pub-8704022903417472/8260634866`
- Rewarded: `ca-app-pub-8704022903417472/4108143571`

Build ini masih meminta unit iklan demo/test resmi Google agar pengujian tidak menghasilkan klik/impression iklan produksi. Setelah pengujian berhasil dan peninjauan kebijakan/target audiens selesai, ganti `bannerUnitId` dan `rewardedUnitId` di `MainActivity.kt` dengan `productionBannerUnitId` dan `productionRewardedUnitId`. Jangan klik iklan produksi sendiri.

Pilihan usia pada build ini hanya penyaring pengalaman iklan berbasis pilihan pengguna, bukan verifikasi usia. Karena aplikasi ditujukan ke audiens campuran, pastikan deklarasi target audiens, perlakuan anak/usia tidak diketahui, privasi, dan persyaratan Google Play Families ditinjau sebelum iklan produksi diaktifkan.


## Dashboard Admin Bank Soal (Firebase Email/Password)

Versi ini menambahkan tombol **Admin** pada halaman utama. Login Admin memakai Firebase Authentication Email/Password melalui sesi Firebase terpisah sehingga sesi anonim pemain tidak diganti. Admin dapat menambah, mengedit, dan menghapus soal tambahan pada node Realtime Database `questionBank`. Soal bawaan tetap tersedia; soal dari Firebase ditambahkan ke kategori terkait saat pemain membuka game.

### Pengaturan Firebase yang wajib dilakukan
1. Firebase Console → Authentication → Sign-in method → aktifkan **Email/Password**.
2. Authentication → Users → Add user. Buat akun Admin. Jangan membagikan kata sandinya.
3. Salin **UID** akun Admin tersebut.
4. Realtime Database → Rules: pertahankan semua aturan lama, lalu tambahkan aturan `questionBank` berikut di dalam objek `"rules"` (ganti `ADMIN_UID_DI_SINI` dengan UID Admin yang dibuat).

```json
"questionBank": {
  ".read": "auth != null",
  ".write": "auth != null && auth.uid === 'ADMIN_UID_DI_SINI'"
}
```

Aturan ini mengizinkan pemain yang sudah login Firebase membaca bank soal, tetapi hanya UID Admin yang ditetapkan yang dapat mengubahnya. Jangan menambahkan hak tulis untuk semua pengguna. Setelah mengubah Rules, tekan **Publish**.

**Catatan:** Dashboard sudah disiapkan di proyek, tetapi koneksi tulis Admin belum dapat diuji dari sini karena memerlukan akun/UID Admin dan Firebase Rules milik pemilik proyek. APK juga belum dibangun atau diuji pada perangkat.


## Versi 3.1.0 – Upgrade profil dan edukasi
- Pendaftaran profil awal: nama, umur, jenjang, dan kelas.
- Foto profil dapat diganti dari perangkat (disimpan lokal di perangkat).
- Soal pengayaan mengikuti jenjang SD/MI, SMP/MTs, SMA/SMK/MA, dan Mahasiswa.
- Statistik dan riwayat permainan lokal.
- Liga mingguan mengarah ke ranking mingguan.
- Gambar puzzle diacak dari beberapa ilustrasi orisinal setiap permainan.
- Kartu cocokkan pasangan menggunakan kumpulan gambar/ikon acak setiap permainan.
- Perbaikan penghitungan langkah puzzle dan hadiah permainan pasangan.

Catatan: ranking online, turnamen, dan hadiah yang aman memerlukan Cloud Functions/server. Rules Firebase yang menolak penulisan skor dari klien akan tetap menolak sinkronisasi skor sampai backend tersebut dipasang.


## Versi 3.2.0 — Arena Duel 2–5 Pemain
- Host dapat memilih kapasitas room 2, 3, 4, atau 5 pemain.
- Room otomatis mulai saat jumlah pemain sesuai kapasitas terpenuhi.
- Semua pemain melihat papan skor dan nyawa seluruh peserta secara real-time.
- Setiap ronde berlanjut setelah seluruh pemain aktif mengirim jawaban.
- Hasil akhir menampilkan urutan peringkat peserta berdasarkan skor.

Catatan: Arena menggunakan Firebase Realtime Database. Rules `arenaRooms` harus mengizinkan pengguna terautentikasi membaca dan menulis room agar fitur dapat berjalan. Penulisan skor oleh klien pada mode Arena belum setara validasi anti-cheat server; untuk kompetisi berhadiah, pindahkan penilaian ke Cloud Functions.
